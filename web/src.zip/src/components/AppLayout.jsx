// src/layout/AppLayout.jsx
import React from 'react';
import { Outlet } from 'react-router-dom';
import AudioPlayer from '../components/AudioPlayer';

function AppLayout() {
  return (
    <>
      <AudioPlayer src="./audio/ambient.mp3" volume={0.2} />
      <Outlet />
    </>
  );
}

export default AppLayout;
