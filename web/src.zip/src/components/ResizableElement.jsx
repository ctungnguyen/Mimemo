import React, { useRef, useState } from 'react';
import '../css/ResizableElement.css';

function ResizableElement({ id, src, text, isSelected, onSelect, style = {}, onResize }) {
  const elementRef = useRef(null);
  const [size, setSize] = useState({ width: style.width || 100, height: style.height || 100 });

  const MIN_SIZE = 30;

  const handleMouseDown = (e, corner) => {
    e.stopPropagation();
    e.preventDefault();
    const startX = e.clientX;
    const startY = e.clientY;
    const startWidth = size.width;
    const startHeight = size.height;

    const handleMouseMove = (moveEvent) => {
      const dx = moveEvent.clientX - startX;
      const dy = moveEvent.clientY - startY;

      let newWidth = startWidth;
      let newHeight = startHeight;

      if (corner.includes('right')) newWidth = Math.max(MIN_SIZE, startWidth + dx);
      if (corner.includes('left')) newWidth = Math.max(MIN_SIZE, startWidth - dx);
      if (corner.includes('bottom')) newHeight = Math.max(MIN_SIZE, startHeight + dy);
      if (corner.includes('top')) newHeight = Math.max(MIN_SIZE, startHeight - dy);

      setSize({ width: newWidth, height: newHeight });
      onResize && onResize({ width: newWidth, height: newHeight });
    };

    const handleMouseUp = () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  return (
    <div
      ref={elementRef}
      className={`resizable-element ${isSelected ? 'selected' : ''}`}
      style={{ ...style, ...size }}
      onClick={() => onSelect(id)}
    >
      {src && <img src={src} alt="sticker" style={{ width: '100%', height: '100%' }} />}
      {text && <div style={{ padding: 4 }}>{text}</div>}

      {isSelected && (
        <>
          <div className="resize-handle top-left" onMouseDown={(e) => handleMouseDown(e, 'top-left')} />
          <div className="resize-handle top-right" onMouseDown={(e) => handleMouseDown(e, 'top-right')} />
          <div className="resize-handle bottom-left" onMouseDown={(e) => handleMouseDown(e, 'bottom-left')} />
          <div className="resize-handle bottom-right" onMouseDown={(e) => handleMouseDown(e, 'bottom-right')} />
        </>
      )}
    </div>
  );
}

export default ResizableElement;
