import React, { useState,useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

import frame from '../assets/wall/wall.png';
import eyeIcon from '../assets/wall/eye.svg';

import blueBg from '../assets/wall/vector-blue.png';
import pinkBg from '../assets/wall/vector-pink.png';
import beigeBg from '../assets/wall/vector-beige.png';
import blackBg from '../assets/wall/vector-black.png';

import ChangeBgColor from '../components/ChangeBgColor';

import "../css/Wall.css";
import { useParams } from 'react-router-dom';

export default function Wall({ hideBgColorUI = false, bgIndex: bgIndexProp }) {
  const { userId } = useParams();

  const location = useLocation();
  const backgrounds = [blueBg, pinkBg, beigeBg, blackBg];

  const initialBgIndex = bgIndexProp !== undefined ? bgIndexProp : (location.state?.bgIndex ?? 0);
  const [bgIndex, setBgIndex] = useState(initialBgIndex);

  // Add this effect to sync state when prop changes
  useEffect(() => {
    if (bgIndexProp !== undefined && bgIndexProp !== bgIndex) {
      setBgIndex(bgIndexProp);
    }
  }, [bgIndexProp]);


  const handleChangeBackground = () => {
    setBgIndex((prev) => (prev + 1) % backgrounds.length);
  };

  return (
    <div className="wall-page">
      <img src={backgrounds[bgIndex]} className="wall-bg" alt="background" />
      
      {!hideBgColorUI && (
        <ChangeBgColor
          backgrounds={backgrounds}
          bgIndex={bgIndex}
          onChange={handleChangeBackground}
        />
      )}

      <header className="wall-header">
        <div className="header-left">logo</div>
        <div className="header-center">emquyttt’s wall</div>
        <div className="header-right">
          <Link to={`/${userId}/wall/edit`} state={{ bgIndex }}>
            <img src={eyeIcon} alt="edit" className="header-icon" />
          </Link>
        </div>
      </header>

      <div className="wall-frame-container">
        <img src={frame} alt="wall frame" className="wall-frame" />
        <div className="pins" />
      </div>

      <footer className="wall-footer">
        decorate your wall ! ^^ decorate your wall ! ^^ decorate your wall ! ^^
      </footer>
    </div>
  );
}
