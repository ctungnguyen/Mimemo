import React, { useState, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';

import frame from '../assets/wall/wall.png';
import backIcon from '../assets/wall/eye-off.svg';
import stickerOff from '../assets/wall/sticker.svg';
import stickerOn from '../assets/wall/sticker-on.svg';

import blueBg from '../assets/wall/vector-blue.png';
import pinkBg from '../assets/wall/vector-pink.png';
import beigeBg from '../assets/wall/vector-beige.png';
import blackBg from '../assets/wall/vector-black.png';

import StickerPicker from '../components/StickerPicker';
import Draggable from 'react-draggable';
import ChangeBgColor from '../components/ChangeBgColor'; // ✅

import "../css/Wall.css";
import { useParams } from 'react-router-dom';


export default function WallEdit() {
  const { userId } = useParams();
  const location = useLocation();
  const backgrounds = [blueBg, pinkBg, beigeBg, blackBg];

  const initialBgIndex = location.state?.bgIndex ?? 0;
  const [bgIndex, setBgIndex] = useState(initialBgIndex);
  const backgroundImage = backgrounds[bgIndex];

  const [showStickers, setShowStickers] = useState(false);
  const [stickersOnWall, setStickersOnWall] = useState([]);
  const stickerRefs = useRef({});

  const handleChangeBackground = () => {
    setBgIndex((prev) => (prev + 1) % backgrounds.length);
  };

  const selectStickers = () => {
    setShowStickers(s => !s);
  };

  const handleAddSticker = (src) => {
    const id = Date.now();
    stickerRefs.current[id] = React.createRef();
    setStickersOnWall(prev => [...prev, { id, src, x: 50, y: 50 }]);
    setShowStickers(false);
  };

  return (
    <div className="wall-page edit-mode">
      <img src={backgroundImage} className="wall-bg" alt="background" />

      <ChangeBgColor // ✅
        backgrounds={backgrounds}
        bgIndex={bgIndex}
        onChange={handleChangeBackground}
      />

      <header className="wall-header">
        <div className="header-left">
          <img
            src={showStickers ? stickerOn : stickerOff}
            alt="toggle stickers"
            className="header-icon"
            onClick={selectStickers}
          />
        </div>
        <div className="header-center">edit your wall</div>
        <div className="header-right">
          <Link to={`/${userId}/wall`} state={{ bgIndex }}>
            <img src={backIcon} alt="back to view" className="header-icon" />
          </Link>
        </div>
      </header>

      <div className="wall-frame-container edit-area">
        <img src={frame} alt="wall frame edit-area" className="wall-frame" />

        {showStickers && <StickerPicker bounds=".edit-area" addSticker={handleAddSticker} />}

        {stickersOnWall.map(({ id, src, x, y }) => (
          <Draggable
            key={id}
            nodeRef={stickerRefs.current[id]}
            bounds=".edit-area"
            defaultPosition={{ x, y }}
          >
            <img
              ref={stickerRefs.current[id]}
              src={src}
              className="sticker-draggable"
              alt="sticker"
              onDoubleClick={e => {
                e.stopPropagation();
                setStickersOnWall(stickersOnWall.filter(s => s.id !== id));
              }}
              style={{ position: 'absolute', cursor: 'move', userSelect: 'none' }}
            />
          </Draggable>
        ))}
      </div>

      <footer className="wall-footer">
        drag &amp; drop stickers, then switch back to view →
      </footer>
    </div>
  );
}
